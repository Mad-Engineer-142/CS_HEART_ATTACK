from new_domain_generating_url import generate_domain_variations
from testing import analyze_urls
from donaim_check import docmain_check
import json
import warnings
import re

def is_cyrillic_domain(domain):
    # Регулярное выражение для поиска кириллических символов
    cyrillic_pattern = re.compile('[а-яА-ЯёЁ]')
    
    # Проверяем, содержит ли домен кириллические символы
    if cyrillic_pattern.search(domain):
        return True
    else:
        return False

def start_parse(domain, fuzzers=['addition', 'bitsquatting', 'omission', 'plural', 'hyphenation', 'subdomain', 'repetition', 'transposition', 'homoglyph', 'insertion', 'replacement', 'vowel_swap', 'dictionary'], tld="ru", subdomain=""):
    dom = generate_domain_variations('', domain, tld, fuzzers,is_cyrillic_domain(domain))    
    print("generate_domain_variations")
    domain_list = docmain_check([d.domain for d in dom])
    print("docmain_check")
    results_dict = analyze_urls(domain_list)
    print("analyze_urls")
    json_data = json.dumps(results_dict, indent=4)

    return results_dict, dom
