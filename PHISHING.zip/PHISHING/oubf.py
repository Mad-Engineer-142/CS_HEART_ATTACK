import ast
import random
import string


class RenameVariables(ast.NodeTransformer):
	def __init__(self):
		self.var_names = {}

	def generate_random_var_name(self, length=8):
		letters = string.ascii_letters
		return ''.join(random.choice(letters) for i in range(length))

	def visit_Name(self, node):
		if isinstance(node.ctx, ast.Store) and node.id not in self.var_names:
			self.var_names[node.id] = self.generate_random_var_name()

		if node.id in self.var_names:
			return ast.copy_location(ast.Name(id=self.var_names[node.id], ctx=node.ctx), node)
		return node


def replace_variables_in_code(code):
	tree = ast.parse(code)
	transformer = RenameVariables()
	tree = transformer.visit(tree)
	return ast.unparse(tree)

