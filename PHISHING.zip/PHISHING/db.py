from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()

class User(db.Model):
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    company_name = db.Column(db.String(255))
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    telegram = db.Column(db.String(80))
    email = db.Column(db.String(120), unique=True, nullable=False)
    user_type = db.Column(db.String(20), nullable=False)
    authenticated = db.Column(db.Boolean, default=False)

    def __init__(self, user_type, company_name, username, password, telegram, email):
        self.user_type = user_type
        self.company_name = company_name
        self.username = username
        self.password_hash = generate_password_hash(password)
        self.telegram = telegram
        self.email = email


    def to_dict(self):
        return {
            'id': self.id,
            'company_name': self.company_name,
            'username': self.username,
            'telegram': self.telegram,
            'email': self.email,
            'user_type': self.user_type,
        }

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def is_active(self):
        return True

    def get_id(self):
        return str(self.id)

    def is_authenticated(self):
        return self.authenticated

    def is_anonymous(self):
        return False




class Domain(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    domain_name = db.Column(db.String(100), unique=True, nullable=False)
    company_id = db.Column(db.Integer, db.ForeignKey('company.id'), nullable=False)
    data = db.Column(db.String(255))  # Add a data field of type String (adjust the length as needed)
    user_availability = db.Column(db.Boolean, default=False)  # Add a boolean field for user availability
    guest_availability = db.Column(db.Boolean, default=False)  # Add a boolean field for guest availability


class Company(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    domains = db.relationship('Domain', backref='company', lazy=True)

