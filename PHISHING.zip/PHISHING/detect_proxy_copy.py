import aiohttp
import asyncio

async def detect_proxy_copy(original_url, proxy_url):
    try:
        async with aiohttp.ClientSession() as session:
            # Получаем данные с оригинального сайта
            async with session.get(original_url) as original_response:
                original_headers = original_response.headers
                original_content = await original_response.text()

            # Получаем данные с потенциальной прокси-копии
            async with session.get(proxy_url) as proxy_response:
                proxy_headers = proxy_response.headers
                proxy_content = await proxy_response.text()

            # Сравниваем HTTP заголовки
            header_differences = set(original_headers.items()) - set(proxy_headers.items())

            # Сравниваем HTML контент
            content_difference = original_content != proxy_content

            return len(header_differences) > 0 or content_difference
    except aiohttp.ClientError:
        return False
