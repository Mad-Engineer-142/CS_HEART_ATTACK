import itertools
import string
import re
import idna
import socket
# Функция bitsquatting
import idna
import re




glyphs_ascii = {
    '0': ('o',),
    '1': ('l', 'i'),
    '3': ('8',),
    '6': ('9',),
    '8': ('3',),
    '9': ('6',),
    'b': ('d', 'lb'),
    'c': ('e',),
    'd': ('b', 'cl', 'dl'),
    'e': ('c',),
    'g': ('q',),
    'h': ('lh'),
    'i': ('1', 'l'),
    'k': ('lc'),
    'l': ('1', 'i'),
    'm': ('n', 'nn', 'rn', 'rr'),
    'n': ('m', 'r'),
    'o': ('0',),
    'q': ('g',),
    'w': ('vv',),
}

latin_to_cyrillic = {
    'a': 'а', 'b': 'ь', 'c': 'с', 'd': 'ԁ', 'e': 'е', 'g': 'ԍ', 'h': 'һ',
    'i': 'і', 'j': 'ј', 'k': 'к', 'l': 'ӏ', 'm': 'м', 'o': 'о', 'p': 'р',
    'q': 'ԛ', 's': 'ѕ', 't': 'т', 'v': 'ѵ', 'w': 'ԝ', 'x': 'х', 'y': 'у',
}

qwerty = {
    '1': '2q', '2': '3wq1', '3': '4ew2', '4': '5re3', '5': '6tr4', '6': '7yt5', '7': '8uy6', '8': '9iu7', '9': '0oi8', '0': 'po9',
    'q': '12wa', 'w': '3esaq2', 'e': '4rdsw3', 'r': '5tfde4', 't': '6ygfr5', 'y': '7uhgt6', 'u': '8ijhy7', 'i': '9okju8', 'o': '0plki9', 'p': 'lo0',
    'a': 'qwsz', 's': 'edxzaw', 'd': 'rfcxse', 'f': 'tgvcdr', 'g': 'yhbvft', 'h': 'ujnbgy', 'j': 'ikmnhu', 'k': 'olmji', 'l': 'kop',
    'z': 'asx', 'x': 'zsdc', 'c': 'xdfv', 'v': 'cfgb', 'b': 'vghn', 'n': 'bhjm', 'm': 'njk'
}
qwertz = {
    '1': '2q', '2': '3wq1', '3': '4ew2', '4': '5re3', '5': '6tr4', '6': '7zt5', '7': '8uz6', '8': '9iu7', '9': '0oi8', '0': 'po9',
    'q': '12wa', 'w': '3esaq2', 'e': '4rdsw3', 'r': '5tfde4', 't': '6zgfr5', 'z': '7uhgt6', 'u': '8ijhz7', 'i': '9okju8', 'o': '0plki9', 'p': 'lo0',
    'a': 'qwsy', 's': 'edxyaw', 'd': 'rfcxse', 'f': 'tgvcdr', 'g': 'zhbvft', 'h': 'ujnbgz', 'j': 'ikmnhu', 'k': 'olmji', 'l': 'kop',
    'y': 'asx', 'x': 'ysdc', 'c': 'xdfv', 'v': 'cfgb', 'b': 'vghn', 'n': 'bhjm', 'm': 'njk'
}
azerty = {
    '1': '2a', '2': '3za1', '3': '4ez2', '4': '5re3', '5': '6tr4', '6': '7yt5', '7': '8uy6', '8': '9iu7', '9': '0oi8', '0': 'po9',
    'a': '2zq1', 'z': '3esqa2', 'e': '4rdsz3', 'r': '5tfde4', 't': '6ygfr5', 'y': '7uhgt6', 'u': '8ijhy7', 'i': '9okju8', 'o': '0plki9', 'p': 'lo0m',
    'q': 'zswa', 's': 'edxwqz', 'd': 'rfcxse', 'f': 'tgvcdr', 'g': 'yhbvft', 'h': 'ujnbgy', 'j': 'iknhu', 'k': 'olji', 'l': 'kopm', 'm': 'lp',
    'w': 'sxq', 'x': 'wsdc', 'c': 'xdfv', 'v': 'cfgb', 'b': 'vghn', 'n': 'bhj'
}
keyboards = [qwerty, qwertz, azerty]

def bitsquatting(domain):
    masks = [1, 2, 4, 8, 16, 32, 64, 128]
    chars = set('abcdefghijklmnopqrstuvwxyz0123456789-')
    for i, c in enumerate(domain):
        for mask in masks:
            b = chr(ord(c) ^ mask)
            if b in chars:
                yield domain[:i] + b + domain[i+1:]

# Функция cyrillic
def cyrillic(domain, latin_to_cyrillic):
    cdomain = domain
    for l, c in latin_to_cyrillic.items():
        cdomain = cdomain.replace(l, c)
    return [cdomain] if cdomain != domain else []

# Функция homoglyph
def homoglyph(domain, glyphs):
    def mix(d):
        for i, c in enumerate(d):
            for g in glyphs.get(c, []):
                yield d[:i] + g + d[i+1:]
    return set(itertools.chain.from_iterable(mix(variant) for variant in mix(domain)))

# Функция hyphenation
def hyphenation(domain):
    return {domain[:i] + '-' + domain[i:] for i in range(1, len(domain))}

# Функция insertion
def insertion(domain, keyboards):
    result = set()
    for i in range(1, len(domain) - 1):
        prefix, orig_c, suffix = domain[:i], domain[i], domain[i+1:]
        for c in (c for keys in keyboards for c in keys.get(orig_c, [])):
            result.add(prefix + c + orig_c + suffix)
            result.add(prefix + orig_c + c + suffix)
    return result
# Функция omission
def omission(domain):
    return {domain[:i] + domain[i+1:] for i in range(len(domain))}

# Функция repetition
def repetition(domain):
    return {domain[:i] + c + domain[i:] for i, c in enumerate(domain)}

# Функция replacement
def replacement(domain, keyboards):
    for i, c in enumerate(domain):
        prefix, suffix = domain[:i], domain[i+1:]
        for layout in keyboards:
            for r in layout.get(c, ''):
                yield prefix + r + suffix

# Функция subdomain
def subdomain(domain):
    for i in range(1, len(domain)-1):
        if domain[i] not in ['-', '.'] and domain[i-1] not in ['-', '.']:
            yield domain[:i] + '.' + domain[i:]

# Функция transposition
def transposition(domain):
    return {domain[:i] + domain[i+1] + domain[i] + domain[i+2:] for i in range(len(domain)-1)}

# Функция vowel_swap
def vowel_swap(domain):
    vowels = 'aeiou'
    for i, c in enumerate(domain):
        if c in vowels:
            for vowel in vowels:
                yield domain[:i] + vowel + domain[i+1:]
# Функция plural
def plural(domain):
    for i in range(2, len(domain)-2):
        yield domain[:i+1] + ('es' if domain[i] in ('s', 'x', 'z') else 's') + domain[i+1:]

# Функция addition
def addition(domain):
    return {domain + chr(i) for i in (*range(48, 58), *range(97, 123))}

# Функция dictionary
wordlist=['org','net', 'pp', 'su',"www"]
def dictionary(domain, wordlist):
    result = set()
    for word in wordlist:
        if not (domain.startswith(word) and domain.endswith(word)):
            result.add(domain + '.' + word)
            result.add(domain + word)
            result.add(word + '.' + domain)
            result.add(word + domain)
    return result

# Функция tld
def tld(domain, tld_list):
    return {domain + '.' + t for t in tld_list}

class Permutation:
    def __init__(self, fuzzer, domain):
        self.fuzzer = fuzzer
        self.domain = domain

    def __repr__(self):
        return f"{self.domain}"

# Определения функций генерации доменов (bitsquatting, cyrillic, hyphenation и т.д.) здесь...

def generate_domain_variations(subdomain, domain, tld, fuzzers=[], keyboards={}):
    # Словарь функций для генерации вариаций
    variation_functions = {
        'addition': addition,
        'bitsquatting': bitsquatting,
        'omission': omission,
        'plural': plural,
        'hyphenation': hyphenation,
        'subdomain': subdomain,
        'repetition': repetition,
        'transposition': transposition,
        'homoglyph': lambda d: homoglyph(d, glyphs_ascii),
        'insertion': lambda d: insertion(d, keyboards),
        'replacement': lambda d: replacement(d, keyboards),
        'vowel_swap': vowel_swap,
        'dictionary': lambda d: dictionary(d, wordlist)
    }

    domains = set()

    for fuzzer in fuzzers:
        method = variation_functions.get(fuzzer)
        if method:
            for variant in method(domain):
                full_domain = '.'.join(filter(None, [subdomain, variant, tld]))
                domains.add(Permutation(fuzzer=fuzzer, domain=full_domain))

    # Конвертация доменов в punycode и фильтрация невалидных
    valid_domain_regex = re.compile(r'^[a-zA-Z\d-]{,63}(\.[a-zA-Z\d-]{,63})*$')
    punycode_domains = set()
    for domain in domains:
        try:
            punycode_domain = idna.encode(domain.domain).decode()
            if valid_domain_regex.match(punycode_domain):
                punycode_domains.add(Permutation(fuzzer=domain.fuzzer, domain=punycode_domain))
        except Exception:
            pass

    return sorted(punycode_domains, key=lambda x: x.domain)