class RequireParamsException(Exception):
    pass