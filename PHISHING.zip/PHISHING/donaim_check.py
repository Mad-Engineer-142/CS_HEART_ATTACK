import asyncio
import aiohttp
import warnings


async def check_domain(domain):
    async with aiohttp.ClientSession() as session:
        try:
            async with session.get(f"http://{domain}") as response:
                if response.status == 200:
                    return domain
                else:
                    return None
        except Exception as e:
            return None

async def check_domains(domains):
    tasks = [check_domain(domain) for domain in domains]
    results = await asyncio.gather(*tasks)
    return results

# Example usage:

def docmain_check(domains_to_check):
    # domains_to_check = ["example.com", "google.com", "nonexistentdomain1234567890.com"]
    results = asyncio.run(check_domains(domains_to_check))
    
    # Filter out None values
    filtered_results = [result for result in results if result is not None]
    return filtered_results
