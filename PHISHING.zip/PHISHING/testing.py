import aiohttp
import asyncio
import requests
import whois
from datetime import datetime
from urllib.parse import urlparse
from bs4 import BeautifulSoup
from ipwhois import IPWhois
from geopy.geocoders import Nominatim
import warnings
import re
import logging

# Импортируем функцию detect_proxy_copy из своего модуля
from detect_proxy_copy import detect_proxy_copy

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
warnings.filterwarnings("ignore")

async def prepare_url(url):
    if not url.startswith(('http://', 'https://')):
        return 'https://' + url
    return url

async def check_ssl_certificate(url, session):
    try:
        async with session.get(url, ssl=False) as response:
            return response.url
    except aiohttp.ClientError:
        return False

async def get_domain_age(domain):
    try:
        domain_info = whois.whois(domain)
        creation_date = domain_info.creation_date
        if isinstance(creation_date, list):
            creation_date = creation_date[0]
        if creation_date:
            return (datetime.now() - creation_date).days
        return -1
    except Exception as e:
        return -1

async def analyze_url(url, trusted_domains, session):
    url = await prepare_url(str(url))
    phishing_flags = [False, False, False, False, False]
    
    bool_const = not await check_ssl_certificate(url, session)
    
    if url in trusted_domains:
        return None

    domain = urlparse(url).netloc
    domain_age = await get_domain_age(domain)

    if domain_age != -1 and domain_age < 3:
        phishing_flags[1] = True
    
    is_proxy_copy = False
    for original_domain in trusted_domains:
        is_proxy_copy = await detect_proxy_copy(original_domain, url)
        if is_proxy_copy:
            phishing_flags[4] = True
            break

    # Вызываем detect_proxy_copy с оригинальным доменом и потенциальной прокси-копией
    # Замените на реальный оригинальный домен
    if bool_const and (is_proxy_copy or any(phishing_flags)):
        phishing_flags[0] = True

    try:
        async with session.get(url) as response:
            html_content = await response.text()

        soup = BeautifulSoup(html_content, 'html.parser')
        
        for phrase in ["банк", "пароль", "кредитная карта", "подтвердите свою личность"]:
            if phrase in soup.get_text().lower():
                phishing_flags[2] = True
                break

        for form in soup.find_all('form'):
            if 'username' in str(form) and 'password' in str(form):
                action_url = form.get('action')
                action_domain = urlparse(action_url).netloc
                if action_domain and action_domain not in trusted_domains:
                    phishing_flags[3] = True
                    break

    except Exception as e:
        pass
        
    bool_checking_phishing = any(phishing_flags)
    return url, bool_checking_phishing, phishing_flags

async def is_phishing(list_url, trusted_domains):
    async with aiohttp.ClientSession() as session:
        tasks = [analyze_url(url, trusted_domains, session) for url in list_url]
        results = await asyncio.gather(*tasks)

        phishing_flags_dist = {}
        for result in results:
            if result is not None:
                url, is_phishing, flags = result
                if is_phishing:
                    phishing_flags_dist[url] = flags

        return phishing_flags_dist

def analyze_urls(list_url):
    # Пример использования
    trusted_domains = []
    phishing_flags_dist = asyncio.run(is_phishing(list_url, trusted_domains))
    return phishing_flags_dist
