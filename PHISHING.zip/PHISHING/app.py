from flask import (
    Flask, render_template, request, redirect, url_for, flash, jsonify,
    send_from_directory
)
from flask_login import (
    LoginManager, UserMixin, login_user, login_required, logout_user, current_user
)
from werkzeug.security import generate_password_hash, check_password_hash
from db import db, User, Domain  # Assuming you have a db module
from datetime import datetime
from pdf2image import convert_from_path
from werkzeug.utils import secure_filename
import new_main
import oubf
import easyocr
import os
import cv2
import numpy as np



app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///your_database.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'your_secret_key'

db.init_app(app)
login_manager = LoginManager()
login_manager.login_view = 'login'
login_manager.init_app(app)

UPLOAD_FOLDER = 'static'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Initialize the OCR reader
reader = easyocr.Reader(['ru', 'en'])


@login_manager.user_loader
def load_user(user_id):
    try:
        user_id = int(user_id)  # Attempt to convert user_id to an integer
    except ValueError:
        return None  # Return None if user_id is not a valid integer

    return User.query.get(user_id)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        user_type = request.form.get('userMode') 
        print("USERMODE ", user_type)
        company_name = request.form.get('company_name', None)
        username = request.form['username']
        password = request.form['password']
        telegram = request.form.get('telegram', None)
        email = request.form['email']

        # Ensure that user_type is provided
        if not user_type:
            flash("User type is required.", 'error')
            return redirect(url_for('register'))

        user = User(user_type, company_name, username, password, telegram, email)
        db.session.add(user)
        db.session.commit()
        flash("Registration successful. You can now log in.", 'success')
        return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        if user and user.check_password(password):
            login_user(user)
            flash("Login successful.", 'success')
            return redirect(url_for('dashboard'))
        else:
            flash("Invalid username or password.", 'error')
    return render_template('login.html')




def get_user_profile(username):
    user = User.query.filter_by(username=username).first()
    print("USER ", user)
    if user:
        return user.to_dict()
    return None


#==========================================================================
@app.route('/search_users', methods=['GET', 'POST'])
@login_required
def add_user():
    if current_user.user_type != 'company':
        flash("Access Denied. Only company users can add users.", 'error')
        return redirect(url_for('profile'))


    comp_name = current_user.company_name

    # Query to get all users who are employees and not associated with a company
    available_employees = User.query.filter(
        User.user_type == 'employee',
        User.company_name == None,
    ).all()

    my_employees= User.query.filter(
        User.user_type == 'employee',
        User.company_name == comp_name,
    ).all()

    print("my_employees", my_employees)

    return render_template('add_user.html', users=available_employees, my_employees=my_employees)



@app.route('/add_to_company', methods=['POST'])
@login_required
def add_to_company():
    # This endpoint should only be accessible by company users.
    if current_user.user_type != 'company':
        return jsonify({'status': 'error', 'message': 'Unauthorized access'}), 403

    data = request.json
    user_id = data.get('user_id')

    user_to_add = User.query.get(user_id)
    print("user_to_add", user_to_add)
    if not user_to_add:
        return jsonify({'status': 'error', 'message': 'User not found'}), 404

    # Prevent adding a user already associated with a company
    if user_to_add.company_name is not None:
        return jsonify({'status': 'error', 'message': 'User is already part of a company'}), 400

    # Add the user to the company
    try:
        user_to_add.company_name = current_user.company_name
        db.session.commit()
        return jsonify({'status': 'success', 'email': user_to_add.email}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'status': 'error', 'message': 'Failed to add user to company'}), 500



@app.route('/delete_user/<int:user_id>', methods=['GET'])
@login_required
def delete_user(user_id):
    # Ensure only company users can delete user details
    if current_user.user_type != 'company':
        flash("Access Denied. Only company users can delete users.", 'error')
        return redirect(url_for('profile'))

    # Fetch the user to be deleted
    user_to_delete = User.query.get(user_id)
    if not user_to_delete:
        flash("User not found.", 'error')
        return redirect(url_for('manage_users'))

    # Check if the user to be deleted belongs to the current user's company
    if user_to_delete.company_name != current_user.company_name:
        flash("You do not have permission to delete this user.", 'error')
        return redirect(url_for('manage_users')), 405

    # Proceed to delete the user's company association
    try:
        user_to_delete.company_name = None  # Remove the company name
        db.session.commit()
        flash("User deleted successfully.", 'success')
    except Exception as e:
        db.session.rollback()
        flash("An error occurred while deleting the user.", 'error')

    return redirect(url_for('add_user'))















@app.route('/add_domain', methods=['GET', 'POST'])
@login_required
def add_domain():
    if current_user.user_type != 'company':
        flash("Access Denied. Only company users can add domains.", 'error')
        return redirect(url_for('index'))

    if request.method == 'POST':
        domain_name = request.form.get('domain_name')
        current_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")  # Get the current date and time as a formatted string
        user_availability = bool(request.form.get('user_availability'))  # Get the user availability field as a boolean
        guest_availability = bool(request.form.get('guest_availability'))  # Get the guest availability field as a boolean

        # Basic validation
        if not domain_name:
            flash("Domain name is required.", 'error')
            return redirect(url_for('add_domain'))

        # Check if domain already exists
        existing_domain = Domain.query.filter_by(domain_name=domain_name).first()
        if existing_domain:
            flash("This domain already exists.", 'error')
            return redirect(url_for('add_domain'))

        # Add new domain with data fields
        new_domain = Domain(
            domain_name=domain_name,
            company_id=current_user.id,
            data=current_date,  # Assign the current date and time
            user_availability=user_availability,  # Assign the user availability field
            guest_availability=guest_availability  # Assign the guest availability field
        )
        db.session.add(new_domain)
        db.session.commit()

        flash("Domain added successfully.", 'success')
        return redirect(url_for('add_domain'))

    company_domains = Domain.query.filter_by(company_id=current_user.id).all()

    return render_template('add_domain.html', companies=company_domains)

@app.route('/profile')
@login_required
def profile():
    print(current_user)
    user_data = get_user_profile(current_user.username)
    if user_data:
        return render_template('profile.html', user_data=user_data)
    return "User not found", 404




def get_company_domains(company_id):
    """
    Retrieve all domains associated with the given company ID.

    :param company_id: The ID of the company.
    :return: A list of Domain objects.
    """
    return Domain.query.filter_by(company_id=company_id).all()


@app.route('/delete_domain/<string:domain_id>', methods=['DELETE'])
@login_required
def delete_domain(domain_id):
    # Ensure only company users can delete domains
    if current_user.user_type != 'company':
        return jsonify({'status': 'error', 'message': 'Unauthorized access'}), 403

    domain = Domain.query.get(domain_id)
    if not domain:
        return jsonify({'status': 'error', 'message': 'Domain not found'}), 404

    # Check if the domain belongs to the current user's company
    if domain.company_id != current_user.id:
        return jsonify({'status': 'error', 'message': 'Unauthorized access'}), 403

    # Delete the domain
    db.session.delete(domain)
    db.session.commit()
    return jsonify({'status': 'success', 'message': 'Domain deleted successfully'}), 200

@app.route('/view_domain/<string:domain_id>', methods=['GET'])
@login_required
def view_domain(domain_id):
    # Ensure only company users can view domains
    if current_user.user_type != 'company':
        flash("Access Denied. Only company users can view domains.", 'error')
        return redirect(url_for('profile'))

    # Retrieve the domain based on the domain_id
    #print(domain_id)

    domain = Domain.query.get(domain_id)
    #print(domain.domain_name)
    if not domain:
        flash("Domain not found.", 'error')
        return redirect(url_for('dashboard'))  # Redirect to a different page

    #new_main.start_parse(domain, tld, fuzzers, subdomain="") 
    #print(domain.domain_name.split(".")[-2])
    #print(domain.domain_name.split(".")[-1])
    info, doms = new_main.start_parse(domain.domain_name.split(".")[-2], tld=domain.domain_name.split(".")[-1])#, tld, fuzzers, subdomain="")
    #print(info)
    print("doms", doms)

    return view_domainF(domain, doms)

@login_required
def view_domainF(domain, doms):
    return render_template('view_domain.html', domain=domain, doms=doms)#, name_asy=current_user.company_name)


@app.route('/dashboard')
@login_required
def dashboard():
    if current_user.user_type != 'company':
        domains = get_company_domains(current_user.id)
        len_domains = len(domains)
        return render_template('dashboard.html', len_domains=len_domains, domains=domains)
    elif current_user.user_type != 'employee':

        domains = get_company_domains(current_user.id)
        len_domains = len(domains)
        return render_template('dashboard.html', len_domains=len_domains, domains=domains)



@app.route('/code', methods=['GET', 'POST'])
@login_required
def code():
    if request.method == 'POST':
        user_input = request.form['user_input']
        res = oubf.replace_variables_in_code(user_input)
        return render_template('fishing.html',  company_name=current_user.company_name, user_input=res)
    return render_template('fishing.html', company_name=current_user.company_name, user_input=""" ENtdQdOu = 7
DXDxjAvF = 1
if ENtdQdOu < 0:
    print('Sorry, factorial does not exist for negative numbers')
elif ENtdQdOu == 0:
    print('The factorial of 0 is 1')
else:
    for ahYugBwZ in range(1, ENtdQdOu + 1):
        DXDxjAvF = DXDxjAvF * ahYugBwZ
    print('The factorial of', ENtdQdOu, 'is', DXDxjAvF)
    https://github.com/Mad-Engineer-142/ttest/blob/main/ytechka.py""")








#OCR PART
def convert_pdf_to_images(pdf_path, output_folder):
    images = convert_from_path(pdf_path, output_folder=output_folder)
    return images

def perform_ocr_on_images(images):
    results = []
    for idx, img in enumerate(images):
        img_path = os.path.join(app.config['UPLOAD_FOLDER'], f'processed_page_{idx}.png')
        img.save(img_path)

        result = reader.readtext(img_path)
        results.append(result)

    return results

@app.route('/ocr')
def index_ocr():
    return render_template('ocr.html')

@app.route('/upload', methods=['POST'])
def upload():
    if 'file' not in request.files:
        return redirect(request.url)

    file = request.files['file']

    if file:
        filename = secure_filename(file.filename)
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(file_path)

        if file.filename.endswith('.pdf'):
            # Convert PDF to images
            images = convert_pdf_to_images(file_path, app.config['UPLOAD_FOLDER'])

            # Perform OCR on images
            results = perform_ocr_on_images(images)

            return render_template('result.html', filename=filename, num_pages=len(images), results=results)

        elif file.filename.lower().endswith(('.png', '.jpg', '.jpeg')):
            # Perform OCR on the single image
            img = cv2.imread(file_path)
            result = reader.readtext(file_path)
            print(file_path)
            for item in result:
                pts = np.array(item[0], np.int32)
                pts = pts.reshape((-1, 1, 2))
                cv2.polylines(img, [pts], isClosed=True, color=(255, 0, 0), thickness=2)

            result_filepath = os.path.join(app.config['UPLOAD_FOLDER'], 'result_' + filename)
            #rrnigger = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            cv2.imwrite(result_filepath, img)

            num_rectangles = len(result)
            print(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            return render_template('result.html', filename='result_' + filename, num_rectangles=num_rectangles, text=result)
    print(os.path.join(app.config['UPLOAD_FOLDER'], filename))
    return render_template('index.html', error='Invalid file format. Please upload an image or a PDF file.')

@app.route('/static/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)



@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True, host="0.0.0.0", port=5002)
