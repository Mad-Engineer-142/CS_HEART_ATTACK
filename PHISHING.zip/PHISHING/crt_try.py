import psycopg2
from psycopg2.extras import RealDictCursor

def search_similar_domains(domain):
    # Database connection parameters - adjust as needed

    crt_database = "certwatch"
    crt_user     = "guest"
    crt_host     = "91.199.212.73"
    crt_port     = "5432"
    crt_sslmode  = "disable"

    # Connect to the database
    conn = psycopg2.connect(database=crt_database, user=crt_user, host=crt_host, port=crt_port, sslmode=crt_sslmode)
    cursor = conn.cursor()

    # SQL query
    query = """
    WITH ci AS (
        SELECT min(sub.CERTIFICATE_ID) ID,
               ...
               WHERE plainto_tsquery('certwatch', %s) @@ identities(sub.CERTIFICATE)
                   AND sub.NAME_VALUE ILIKE ('%' || %s || '%')
               ...
    )
    SELECT ...
    FROM ci
    ...
    WHERE ci.ISSUER_CA_ID = ca.ID
    ORDER BY le.ENTRY_TIMESTAMP DESC NULLS LAST;
    """

    # Execute the query
    cursor.execute(query, (domain, domain))

    # Fetch and process the results
    results = cursor.fetchall()
    for result in results:
        print(result)  # Or process/format the result as needed


# Example usage
search_similar_domains('sberbank.ru')
